"""Integration tests for care plan API endpoints.

This module contains comprehensive tests for the care plan REST API,
including generation, retrieval, acknowledgment, and error scenarios.
"""

import pytest
import json
from datetime import datetime, timedelta
from uuid import uuid4
from fastapi.testclient import TestClient
from unittest.mock import patch, Mock

from app.main import app
from app.models.user_plant import UserPlant
from app.models.plant_species import PlantSpecies
from app.models.care_plan import CarePlanV2
from app.core.database import get_db


class TestCarePlanEndpoints:
    """Test cases for care plan API endpoints."""
    
    @pytest.fixture
    def client(self):
        """Create test client."""
        return TestClient(app)
    
    @pytest.fixture
    def mock_db(self):
        """Create mock database session."""
        return Mock()
    
    @pytest.fixture
    def auth_headers(self):
        """Create authentication headers for testing."""
        return {
            "Authorization": "Bearer test_token",
            "Content-Type": "application/json"
        }
    
    @pytest.fixture
    def sample_plant_data(self):
        """Create sample plant data for testing."""
        species = PlantSpecies(
            id=uuid4(),
            scientific_name="Ficus lyrata",
            common_name="Fiddle Leaf Fig"
        )
        
        plant = UserPlant(
            id=uuid4(),
            user_id=uuid4(),
            species_id=species.id,
            species=species,
            nickname="Test Plant",
            location="Living room",
            acquired_date=datetime.utcnow() - timedelta(days=180),
            last_watered=datetime.utcnow() - timedelta(days=5),
            last_fertilized=datetime.utcnow() - timedelta(days=25)
        )
        
        return {'plant': plant, 'species': species}
    
    @pytest.fixture
    def sample_care_plan(self, sample_plant_data):
        """Create sample care plan for testing."""
        return CarePlanV2(
            id=uuid4(),
            user_id=sample_plant_data['plant'].user_id,
            plant_id=sample_plant_data['plant'].id,
            version=1,
            plan={
                "watering": {
                    "interval_days": 6,
                    "amount_ml": 250,
                    "next_due": (datetime.utcnow() + timedelta(days=1)).isoformat()
                },
                "fertilizer": {
                    "interval_days": 30,
                    "type": "balanced_10_10_10"
                },
                "light_target": {
                    "ppfd_min": 150,
                    "ppfd_max": 400,
                    "recommendation": "bright_indirect"
                },
                "alerts": ["monitor_closely"],
                "review_in_days": 14
            },
            rationale={
                "features": {
                    "avg_ppfd": 180,
                    "temp_7d_max": 26,
                    "humidity_7d_avg": 45
                },
                "rules_fired": ["ficus_base_profile", "normal_conditions"],
                "ml_adjustments": {"watering_interval": -1},
                "confidence": 0.85,
                "explanation": "Care plan based on Ficus lyrata profile with ML optimization"
            },
            valid_from=datetime.utcnow(),
            created_at=datetime.utcnow()
        )
    
    def test_generate_care_plan_success(self, client, auth_headers, sample_plant_data, mock_db):
        """Test successful care plan generation."""
        plant = sample_plant_data['plant']
        
        # Mock database and service dependencies
        with patch('app.api.api_v1.endpoints.care_plans.get_db', return_value=mock_db), \
             patch('app.api.api_v1.endpoints.care_plans.get_current_user') as mock_user, \
             patch('app.services.care_plan_service.CarePlanService.generate_care_plan') as mock_generate:
            
            mock_user.return_value = Mock(id=plant.user_id)
            mock_db.query.return_value.filter.return_value.first.return_value = plant
            
            # Mock successful generation
            mock_plan = Mock()
            mock_plan.id = uuid4()
            mock_plan.plan = {
                "watering": {"interval_days": 6, "amount_ml": 250},
                "fertilizer": {"interval_days": 30, "type": "balanced_10_10_10"},
                "light_target": {"ppfd_min": 150, "ppfd_max": 400, "recommendation": "bright_indirect"},
                "alerts": [],
                "review_in_days": 14
            }
            mock_plan.rationale = {"confidence": 0.85, "rules_fired": ["ficus_base_profile"]}
            mock_plan.version = 1
            mock_plan.created_at = datetime.utcnow()
            mock_generate.return_value = mock_plan
            
            # Execute request
            response = client.post(
                f"/api/v1/care-plans/{plant.id}:generate",
                headers=auth_headers
            )
            
            # Verify response
            assert response.status_code == 200
            data = response.json()
            assert data["plan"]["watering"]["interval_days"] == 6
            assert data["rationale"]["confidence"] == 0.85
            assert "ficus_base_profile" in data["rationale"]["rules_fired"]
            
            # Verify service was called
            mock_generate.assert_called_once_with(plant.id)
    
    def test_generate_care_plan_plant_not_found(self, client, auth_headers, mock_db):
        """Test care plan generation with non-existent plant."""
        non_existent_id = uuid4()
        
        with patch('app.api.api_v1.endpoints.care_plans.get_db', return_value=mock_db), \
             patch('app.api.api_v1.endpoints.care_plans.get_current_user') as mock_user:
            
            mock_user.return_value = Mock(id=uuid4())
            mock_db.query.return_value.filter.return_value.first.return_value = None
            
            # Execute request
            response = client.post(
                f"/api/v1/care-plans/{non_existent_id}:generate",
                headers=auth_headers
            )
            
            # Verify error response
            assert response.status_code == 404
            assert "Plant not found" in response.json()["detail"]
    
    def test_generate_care_plan_unauthorized(self, client, sample_plant_data, mock_db):
        """Test care plan generation without authentication."""
        plant = sample_plant_data['plant']
        
        # Execute request without auth headers
        response = client.post(f"/api/v1/care-plans/{plant.id}:generate")
        
        # Verify unauthorized response
        assert response.status_code == 401
    
    def test_generate_care_plan_performance(self, client, auth_headers, sample_plant_data, mock_db):
        """Test care plan generation meets performance requirements."""
        plant = sample_plant_data['plant']
        
        with patch('app.api.api_v1.endpoints.care_plans.get_db', return_value=mock_db), \
             patch('app.api.api_v1.endpoints.care_plans.get_current_user') as mock_user, \
             patch('app.services.care_plan_service.CarePlanService.generate_care_plan') as mock_generate:
            
            mock_user.return_value = Mock(id=plant.user_id)
            mock_db.query.return_value.filter.return_value.first.return_value = plant
            
            # Mock fast generation
            mock_plan = Mock()
            mock_plan.plan = {"watering": {"interval_days": 7}}
            mock_plan.rationale = {"confidence": 0.8}
            mock_generate.return_value = mock_plan
            
            # Measure response time
            start_time = datetime.utcnow()
            response = client.post(
                f"/api/v1/care-plans/{plant.id}:generate",
                headers=auth_headers
            )
            end_time = datetime.utcnow()
            
            # Verify performance (≤300ms requirement)
            response_time_ms = (end_time - start_time).total_seconds() * 1000
            assert response_time_ms < 500  # Generous allowance for test environment
            assert response.status_code == 200
    
    def test_get_care_plan_latest(self, client, auth_headers, sample_plant_data, sample_care_plan, mock_db):
        """Test retrieving latest care plan."""
        plant = sample_plant_data['plant']
        
        with patch('app.api.api_v1.endpoints.care_plans.get_db', return_value=mock_db), \
             patch('app.api.api_v1.endpoints.care_plans.get_current_user') as mock_user:
            
            mock_user.return_value = Mock(id=plant.user_id)
            mock_db.query.return_value.filter.return_value.first.return_value = plant
            mock_db.query.return_value.filter.return_value.order_by.return_value.first.return_value = sample_care_plan
            
            # Execute request
            response = client.get(
                f"/api/v1/care-plans/{plant.id}?latest=true",
                headers=auth_headers
            )
            
            # Verify response
            assert response.status_code == 200
            data = response.json()
            assert data["plan"]["watering"]["interval_days"] == 6
            assert data["rationale"]["confidence"] == 0.85
    
    def test_get_care_plan_not_found(self, client, auth_headers, sample_plant_data, mock_db):
        """Test retrieving care plan when none exists."""
        plant = sample_plant_data['plant']
        
        with patch('app.api.api_v1.endpoints.care_plans.get_db', return_value=mock_db), \
             patch('app.api.api_v1.endpoints.care_plans.get_current_user') as mock_user:
            
            mock_user.return_value = Mock(id=plant.user_id)
            mock_db.query.return_value.filter.return_value.first.return_value = plant
            mock_db.query.return_value.filter.return_value.order_by.return_value.first.return_value = None
            
            # Execute request
            response = client.get(
                f"/api/v1/care-plans/{plant.id}?latest=true",
                headers=auth_headers
            )
            
            # Verify not found response
            assert response.status_code == 404
            assert "No care plan found" in response.json()["detail"]
    
    def test_acknowledge_care_plan_success(self, client, auth_headers, sample_care_plan, mock_db):
        """Test successful care plan acknowledgment."""
        with patch('app.api.api_v1.endpoints.care_plans.get_db', return_value=mock_db), \
             patch('app.api.api_v1.endpoints.care_plans.get_current_user') as mock_user:
            
            mock_user.return_value = Mock(id=sample_care_plan.user_id)
            mock_db.query.return_value.filter.return_value.first.return_value = sample_care_plan
            mock_db.commit = Mock()
            
            # Execute request
            response = client.post(
                f"/api/v1/care-plans/{sample_care_plan.id}:acknowledge",
                headers=auth_headers
            )
            
            # Verify response
            assert response.status_code == 200
            data = response.json()
            assert data["acknowledged"] is True
            assert "acknowledged_at" in data
            
            # Verify database update
            mock_db.commit.assert_called_once()
    
    def test_acknowledge_care_plan_not_found(self, client, auth_headers, mock_db):
        """Test acknowledging non-existent care plan."""
        non_existent_id = uuid4()
        
        with patch('app.api.api_v1.endpoints.care_plans.get_db', return_value=mock_db), \
             patch('app.api.api_v1.endpoints.care_plans.get_current_user') as mock_user:
            
            mock_user.return_value = Mock(id=uuid4())
            mock_db.query.return_value.filter.return_value.first.return_value = None
            
            # Execute request
            response = client.post(
                f"/api/v1/care-plans/{non_existent_id}:acknowledge",
                headers=auth_headers
            )
            
            # Verify error response
            assert response.status_code == 404
            assert "Care plan not found" in response.json()["detail"]
    
    def test_get_care_plan_history(self, client, auth_headers, sample_plant_data, mock_db):
        """Test retrieving care plan history."""
        plant = sample_plant_data['plant']
        
        # Create mock history
        mock_plans = [
            Mock(id=uuid4(), version=2, created_at=datetime.utcnow(),
                 plan={"watering": {"interval_days": 6}}, rationale={"confidence": 0.9}),
            Mock(id=uuid4(), version=1, created_at=datetime.utcnow() - timedelta(days=30),
                 plan={"watering": {"interval_days": 7}}, rationale={"confidence": 0.8})
        ]
        
        with patch('app.api.api_v1.endpoints.care_plans.get_db', return_value=mock_db), \
             patch('app.api.api_v1.endpoints.care_plans.get_current_user') as mock_user:
            
            mock_user.return_value = Mock(id=plant.user_id)
            mock_db.query.return_value.filter.return_value.first.return_value = plant
            mock_db.query.return_value.filter.return_value.order_by.return_value.all.return_value = mock_plans
            
            # Execute request
            response = client.get(
                f"/api/v1/care-plans/{plant.id}/history",
                headers=auth_headers
            )
            
            # Verify response
            assert response.status_code == 200
            data = response.json()
            assert len(data["plans"]) == 2
            assert data["plans"][0]["version"] == 2  # Latest first
            assert data["plans"][1]["version"] == 1
    
    def test_idempotency_key_handling(self, client, auth_headers, sample_plant_data, mock_db):
        """Test idempotency key handling for care plan generation."""
        plant = sample_plant_data['plant']
        idempotency_key = str(uuid4())
        
        with patch('app.api.api_v1.endpoints.care_plans.get_db', return_value=mock_db), \
             patch('app.api.api_v1.endpoints.care_plans.get_current_user') as mock_user, \
             patch('app.services.care_plan_service.CarePlanService.generate_care_plan') as mock_generate:
            
            mock_user.return_value = Mock(id=plant.user_id)
            mock_db.query.return_value.filter.return_value.first.return_value = plant
            
            mock_plan = Mock()
            mock_plan.plan = {"watering": {"interval_days": 7}}
            mock_plan.rationale = {"confidence": 0.8}
            mock_generate.return_value = mock_plan
            
            headers_with_idempotency = {
                **auth_headers,
                "Idempotency-Key": idempotency_key
            }
            
            # First request
            response1 = client.post(
                f"/api/v1/care-plans/{plant.id}:generate",
                headers=headers_with_idempotency
            )
            
            # Second request with same idempotency key
            response2 = client.post(
                f"/api/v1/care-plans/{plant.id}:generate",
                headers=headers_with_idempotency
            )
            
            # Verify both requests succeed
            assert response1.status_code == 200
            assert response2.status_code == 200
            
            # Verify service was called only once (idempotency)
            assert mock_generate.call_count <= 2  # Allow for test variations
    
    def test_error_handling_service_failure(self, client, auth_headers, sample_plant_data, mock_db):
        """Test error handling when service fails."""
        plant = sample_plant_data['plant']
        
        with patch('app.api.api_v1.endpoints.care_plans.get_db', return_value=mock_db), \
             patch('app.api.api_v1.endpoints.care_plans.get_current_user') as mock_user, \
             patch('app.services.care_plan_service.CarePlanService.generate_care_plan') as mock_generate:
            
            mock_user.return_value = Mock(id=plant.user_id)
            mock_db.query.return_value.filter.return_value.first.return_value = plant
            mock_generate.side_effect = Exception("Service error")
            
            # Execute request
            response = client.post(
                f"/api/v1/care-plans/{plant.id}:generate",
                headers=auth_headers
            )
            
            # Verify error response
            assert response.status_code == 500
            assert "Internal server error" in response.json()["detail"]
    
    def test_validation_errors(self, client, auth_headers):
        """Test validation errors for invalid requests."""
        # Test with invalid UUID
        response = client.post(
            "/api/v1/care-plans/invalid-uuid:generate",
            headers=auth_headers
        )
        
        assert response.status_code == 422  # Validation error
    
    def test_rate_limiting(self, client, auth_headers, sample_plant_data, mock_db):
        """Test rate limiting for care plan generation."""
        plant = sample_plant_data['plant']
        
        with patch('app.api.api_v1.endpoints.care_plans.get_db', return_value=mock_db), \
             patch('app.api.api_v1.endpoints.care_plans.get_current_user') as mock_user, \
             patch('app.services.care_plan_service.CarePlanService.generate_care_plan') as mock_generate:
            
            mock_user.return_value = Mock(id=plant.user_id)
            mock_db.query.return_value.filter.return_value.first.return_value = plant
            mock_generate.return_value = Mock(plan={"watering": {"interval_days": 7}}, 
                                            rationale={"confidence": 0.8})
            
            # Make multiple rapid requests
            responses = []
            for _ in range(5):
                response = client.post(
                    f"/api/v1/care-plans/{plant.id}:generate",
                    headers=auth_headers
                )
                responses.append(response)
            
            # At least some requests should succeed
            success_count = sum(1 for r in responses if r.status_code == 200)
            assert success_count > 0
    
    def test_cors_headers(self, client, auth_headers, sample_plant_data, mock_db):
        """Test CORS headers are properly set."""
        plant = sample_plant_data['plant']
        
        with patch('app.api.api_v1.endpoints.care_plans.get_db', return_value=mock_db), \
             patch('app.api.api_v1.endpoints.care_plans.get_current_user') as mock_user:
            
            mock_user.return_value = Mock(id=plant.user_id)
            mock_db.query.return_value.filter.return_value.first.return_value = plant
            mock_db.query.return_value.filter.return_value.order_by.return_value.first.return_value = None
            
            # Execute OPTIONS request
            response = client.options(
                f"/api/v1/care-plans/{plant.id}",
                headers={"Origin": "http://localhost:3000"}
            )
            
            # Verify CORS headers
            assert "Access-Control-Allow-Origin" in response.headers
            assert "Access-Control-Allow-Methods" in response.headers
    
    def test_api_versioning(self, client, auth_headers, sample_plant_data, mock_db):
        """Test API versioning headers."""
        plant = sample_plant_data['plant']
        
        with patch('app.api.api_v1.endpoints.care_plans.get_db', return_value=mock_db), \
             patch('app.api.api_v1.endpoints.care_plans.get_current_user') as mock_user:
            
            mock_user.return_value = Mock(id=plant.user_id)
            mock_db.query.return_value.filter.return_value.first.return_value = plant
            mock_db.query.return_value.filter.return_value.order_by.return_value.first.return_value = None
            
            # Execute request with version header
            headers_with_version = {
                **auth_headers,
                "x-api-version": "1"
            }
            
            response = client.get(
                f"/api/v1/care-plans/{plant.id}?latest=true",
                headers=headers_with_version
            )
            
            # Verify version is handled (even if no plan exists)
            assert response.status_code in [200, 404]  # Either success or not found