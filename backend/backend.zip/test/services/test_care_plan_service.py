"""Unit tests for care plan service.

This module contains comprehensive tests for the care plan generation,
rule engine, ML adjustments, and rationale building functionality.
"""

import pytest
from datetime import datetime, timedelta
from unittest.mock import Mock, patch, AsyncMock
from uuid import uuid4

from app.services.care_plan_service import CarePlanService
from app.services.context_aggregator_service import ContextAggregatorService
from app.services.rule_engine_service import RuleEngineService
from app.services.ml_adjustment_service import MLAdjustmentService
from app.services.rationale_builder_service import RationaleBuilderService
from app.models.care_plan import CarePlanV2
from app.models.user_plant import UserPlant
from app.models.plant_species import PlantSpecies


class TestCarePlanService:
    """Test cases for CarePlanService."""
    
    @pytest.fixture
    def mock_dependencies(self):
        """Create mock dependencies for testing."""
        return {
            'context_aggregator': Mock(spec=ContextAggregatorService),
            'rule_engine': Mock(spec=RuleEngineService),
            'ml_adjustment': Mock(spec=MLAdjustmentService),
            'rationale_builder': Mock(spec=RationaleBuilderService),
            'db': Mock()
        }
    
    @pytest.fixture
    def care_plan_service(self, mock_dependencies):
        """Create CarePlanService instance with mocked dependencies."""
        return CarePlanService(
            context_aggregator=mock_dependencies['context_aggregator'],
            rule_engine=mock_dependencies['rule_engine'],
            ml_adjustment=mock_dependencies['ml_adjustment'],
            rationale_builder=mock_dependencies['rationale_builder'],
            db=mock_dependencies['db']
        )
    
    @pytest.fixture
    def sample_plant(self):
        """Create sample plant for testing."""
        species = PlantSpecies(
            id=uuid4(),
            scientific_name="Ficus lyrata",
            common_name="Fiddle Leaf Fig"
        )
        
        return UserPlant(
            id=uuid4(),
            user_id=uuid4(),
            species_id=species.id,
            species=species,
            nickname="My Fiddle",
            location="Living room",
            acquired_date=datetime.utcnow() - timedelta(days=180),
            last_watered=datetime.utcnow() - timedelta(days=5),
            last_fertilized=datetime.utcnow() - timedelta(days=25)
        )
    
    @pytest.fixture
    def sample_context(self):
        """Create sample context data for testing."""
        return {
            'plant_age_months': 6,
            'last_watered_days_ago': 5,
            'last_fertilized_days_ago': 25,
            'avg_light_ppfd': 180,
            'location': 'Living room',
            'pot_size_ml': 1500,
            'pot_material': 'ceramic',
            'climate_data': {
                'temp_7d_avg': 22,
                'temp_7d_max': 26,
                'temp_7d_min': 18,
                'humidity_7d_avg': 45,
                'forecast_7d': []
            },
            'care_history': {
                'watering_frequency_avg': 6,
                'fertilizer_frequency_avg': 28,
                'health_issues': []
            }
        }
    
    @pytest.fixture
    def sample_base_plan(self):
        """Create sample base care plan from rules."""
        return {
            'watering': {
                'interval_days': 7,
                'amount_ml': 300,
                'next_due': (datetime.utcnow() + timedelta(days=2)).isoformat()
            },
            'fertilizer': {
                'interval_days': 30,
                'type': 'balanced_10_10_10'
            },
            'light_target': {
                'ppfd_min': 150,
                'ppfd_max': 400,
                'recommendation': 'bright_indirect'
            },
            'alerts': [],
            'review_in_days': 14
        }
    
    @pytest.mark.asyncio
    async def test_generate_care_plan_success(self, care_plan_service, mock_dependencies, 
                                            sample_plant, sample_context, sample_base_plan):
        """Test successful care plan generation."""
        # Setup mocks
        mock_dependencies['context_aggregator'].aggregate_context.return_value = sample_context
        mock_dependencies['rule_engine'].apply_rules.return_value = sample_base_plan
        mock_dependencies['ml_adjustment'].adjust_plan.return_value = {
            **sample_base_plan,
            'watering': {**sample_base_plan['watering'], 'interval_days': 6}
        }
        mock_dependencies['rationale_builder'].build_rationale.return_value = {
            'features': {'avg_ppfd': 180, 'temp_7d_max': 26},
            'rules_fired': ['ficus_base_profile', 'normal_conditions'],
            'ml_adjustments': {'watering_interval': -1},
            'confidence': 0.85
        }
        
        # Mock database operations
        mock_dependencies['db'].query.return_value.filter.return_value.first.return_value = sample_plant
        mock_dependencies['db'].add = Mock()
        mock_dependencies['db'].commit = Mock()
        mock_dependencies['db'].refresh = Mock()
        
        # Execute
        result = await care_plan_service.generate_care_plan(sample_plant.id)
        
        # Verify
        assert result is not None
        assert result.plan['watering']['interval_days'] == 6
        assert result.rationale['confidence'] == 0.85
        assert 'ficus_base_profile' in result.rationale['rules_fired']
        
        # Verify service calls
        mock_dependencies['context_aggregator'].aggregate_context.assert_called_once_with(sample_plant)
        mock_dependencies['rule_engine'].apply_rules.assert_called_once()
        mock_dependencies['ml_adjustment'].adjust_plan.assert_called_once()
        mock_dependencies['rationale_builder'].build_rationale.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_generate_care_plan_plant_not_found(self, care_plan_service, mock_dependencies):
        """Test care plan generation with non-existent plant."""
        # Setup mock to return None
        mock_dependencies['db'].query.return_value.filter.return_value.first.return_value = None
        
        # Execute and verify exception
        with pytest.raises(ValueError, match="Plant not found"):
            await care_plan_service.generate_care_plan(uuid4())
    
    @pytest.mark.asyncio
    async def test_generate_care_plan_with_environmental_alerts(self, care_plan_service, 
                                                              mock_dependencies, sample_plant, 
                                                              sample_context, sample_base_plan):
        """Test care plan generation with environmental alerts."""
        # Setup context with heatwave conditions
        heatwave_context = {**sample_context, 'climate_data': {
            **sample_context['climate_data'],
            'temp_7d_max': 35,  # Heatwave condition
            'temp_7d_avg': 32
        }}
        
        # Setup plan with alerts
        plan_with_alerts = {
            **sample_base_plan,
            'watering': {**sample_base_plan['watering'], 'interval_days': 5},
            'alerts': ['heatwave_adjust_-1day', 'monitor_closely']
        }
        
        # Setup mocks
        mock_dependencies['context_aggregator'].aggregate_context.return_value = heatwave_context
        mock_dependencies['rule_engine'].apply_rules.return_value = plan_with_alerts
        mock_dependencies['ml_adjustment'].adjust_plan.return_value = plan_with_alerts
        mock_dependencies['rationale_builder'].build_rationale.return_value = {
            'features': {'temp_7d_max': 35, 'avg_ppfd': 180},
            'rules_fired': ['ficus_base_profile', 'heatwave_adjustment'],
            'confidence': 0.78
        }
        
        mock_dependencies['db'].query.return_value.filter.return_value.first.return_value = sample_plant
        mock_dependencies['db'].add = Mock()
        mock_dependencies['db'].commit = Mock()
        mock_dependencies['db'].refresh = Mock()
        
        # Execute
        result = await care_plan_service.generate_care_plan(sample_plant.id)
        
        # Verify alerts are included
        assert 'heatwave_adjust_-1day' in result.plan['alerts']
        assert 'monitor_closely' in result.plan['alerts']
        assert result.plan['watering']['interval_days'] == 5
        assert 'heatwave_adjustment' in result.rationale['rules_fired']
    
    @pytest.mark.asyncio
    async def test_get_latest_care_plan(self, care_plan_service, mock_dependencies, sample_plant):
        """Test retrieving latest care plan."""
        # Create mock care plan
        mock_plan = CarePlanV2(
            id=uuid4(),
            user_id=sample_plant.user_id,
            plant_id=sample_plant.id,
            version=1,
            plan={'watering': {'interval_days': 7}},
            rationale={'confidence': 0.8},
            valid_from=datetime.utcnow(),
            created_at=datetime.utcnow()
        )
        
        # Setup mock
        mock_dependencies['db'].query.return_value.filter.return_value.order_by.return_value.first.return_value = mock_plan
        
        # Execute
        result = await care_plan_service.get_latest_care_plan(sample_plant.id)
        
        # Verify
        assert result == mock_plan
        assert result.plan['watering']['interval_days'] == 7
    
    @pytest.mark.asyncio
    async def test_acknowledge_care_plan(self, care_plan_service, mock_dependencies):
        """Test care plan acknowledgment."""
        plan_id = uuid4()
        user_id = uuid4()
        
        # Create mock care plan
        mock_plan = CarePlanV2(
            id=plan_id,
            user_id=user_id,
            plant_id=uuid4(),
            version=1,
            plan={'watering': {'interval_days': 7}},
            rationale={'confidence': 0.8},
            valid_from=datetime.utcnow(),
            acknowledged_at=None
        )
        
        # Setup mock
        mock_dependencies['db'].query.return_value.filter.return_value.first.return_value = mock_plan
        mock_dependencies['db'].commit = Mock()
        
        # Execute
        result = await care_plan_service.acknowledge_care_plan(plan_id, user_id)
        
        # Verify
        assert result.acknowledged_at is not None
        assert result.acknowledged_by == user_id
        mock_dependencies['db'].commit.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_get_care_plan_history(self, care_plan_service, mock_dependencies):
        """Test retrieving care plan history."""
        plant_id = uuid4()
        
        # Create mock care plans
        mock_plans = [
            CarePlanV2(id=uuid4(), plant_id=plant_id, version=2, created_at=datetime.utcnow()),
            CarePlanV2(id=uuid4(), plant_id=plant_id, version=1, 
                      created_at=datetime.utcnow() - timedelta(days=30))
        ]
        
        # Setup mock
        mock_dependencies['db'].query.return_value.filter.return_value.order_by.return_value.all.return_value = mock_plans
        
        # Execute
        result = await care_plan_service.get_care_plan_history(plant_id)
        
        # Verify
        assert len(result) == 2
        assert result[0].version == 2  # Latest first
        assert result[1].version == 1
    
    def test_plan_versioning(self, care_plan_service, mock_dependencies, sample_plant):
        """Test care plan version increment logic."""
        # Mock existing plan
        existing_plan = CarePlanV2(
            id=uuid4(),
            plant_id=sample_plant.id,
            version=3,
            created_at=datetime.utcnow() - timedelta(days=1)
        )
        
        mock_dependencies['db'].query.return_value.filter.return_value.order_by.return_value.first.return_value = existing_plan
        
        # Test version increment
        next_version = care_plan_service._get_next_version(sample_plant.id)
        assert next_version == 4
    
    def test_plan_comparison(self, care_plan_service):
        """Test care plan comparison for detecting changes."""
        plan1 = {
            'watering': {'interval_days': 7, 'amount_ml': 300},
            'fertilizer': {'interval_days': 30, 'type': 'balanced_10_10_10'}
        }
        
        plan2 = {
            'watering': {'interval_days': 6, 'amount_ml': 300},  # Changed interval
            'fertilizer': {'interval_days': 30, 'type': 'balanced_10_10_10'}
        }
        
        plan3 = {
            'watering': {'interval_days': 7, 'amount_ml': 300},
            'fertilizer': {'interval_days': 30, 'type': 'balanced_10_10_10'}
        }
        
        # Test different plans
        assert care_plan_service._plans_differ(plan1, plan2) is True
        
        # Test identical plans
        assert care_plan_service._plans_differ(plan1, plan3) is False
    
    @pytest.mark.asyncio
    async def test_performance_requirement(self, care_plan_service, mock_dependencies, 
                                         sample_plant, sample_context, sample_base_plan):
        """Test that care plan generation meets ≤300ms requirement."""
        # Setup fast mocks
        mock_dependencies['context_aggregator'].aggregate_context.return_value = sample_context
        mock_dependencies['rule_engine'].apply_rules.return_value = sample_base_plan
        mock_dependencies['ml_adjustment'].adjust_plan.return_value = sample_base_plan
        mock_dependencies['rationale_builder'].build_rationale.return_value = {
            'confidence': 0.8, 'rules_fired': [], 'features': {}
        }
        
        mock_dependencies['db'].query.return_value.filter.return_value.first.return_value = sample_plant
        mock_dependencies['db'].add = Mock()
        mock_dependencies['db'].commit = Mock()
        mock_dependencies['db'].refresh = Mock()
        
        # Measure execution time
        start_time = datetime.utcnow()
        await care_plan_service.generate_care_plan(sample_plant.id)
        end_time = datetime.utcnow()
        
        execution_time_ms = (end_time - start_time).total_seconds() * 1000
        
        # Verify performance requirement (allowing for test overhead)
        assert execution_time_ms < 500  # Generous allowance for test environment
    
    @pytest.mark.asyncio
    async def test_error_handling(self, care_plan_service, mock_dependencies, sample_plant):
        """Test error handling in care plan generation."""
        # Setup mock to raise exception
        mock_dependencies['context_aggregator'].aggregate_context.side_effect = Exception("Context error")
        mock_dependencies['db'].query.return_value.filter.return_value.first.return_value = sample_plant
        
        # Execute and verify exception handling
        with pytest.raises(Exception, match="Context error"):
            await care_plan_service.generate_care_plan(sample_plant.id)
    
    def test_ml_bounds_enforcement(self, care_plan_service):
        """Test ML adjustment bounds are properly enforced."""
        base_plan = {
            'watering': {'interval_days': 7, 'amount_ml': 300},
            'fertilizer': {'interval_days': 30}
        }
        
        # Test extreme ML adjustments are bounded
        ml_adjustments = {
            'watering_interval': -10,  # Extreme adjustment
            'watering_amount': +500,   # Extreme adjustment
            'fertilizer_interval': +100  # Extreme adjustment
        }
        
        bounded_plan = care_plan_service._apply_ml_bounds(base_plan, ml_adjustments)
        
        # Verify bounds are enforced (±30% max)
        assert bounded_plan['watering']['interval_days'] >= 5  # 7 - 30% ≈ 5
        assert bounded_plan['watering']['interval_days'] <= 9  # 7 + 30% ≈ 9
        assert bounded_plan['watering']['amount_ml'] <= 390   # 300 + 30% = 390
        assert bounded_plan['fertilizer']['interval_days'] <= 39  # 30 + 30% = 39


class TestRuleEngineService:
    """Test cases for RuleEngineService."""
    
    @pytest.fixture
    def rule_engine(self):
        """Create RuleEngineService instance."""
        return RuleEngineService()
    
    def test_load_species_rules(self, rule_engine):
        """Test loading species rules from YAML."""
        rules = rule_engine.load_species_rules()
        
        assert 'ficus_lyrata' in rules['species_profiles']
        assert 'monstera_deliciosa' in rules['species_profiles']
        assert 'global_modifiers' in rules
    
    def test_apply_base_rules(self, rule_engine):
        """Test applying base species rules."""
        context = {
            'species_scientific_name': 'ficus_lyrata',
            'plant_age_months': 12,
            'pot_size_ml': 1500
        }
        
        plan = rule_engine.apply_rules(context)
        
        assert plan['watering']['interval_days'] == 7
        assert plan['fertilizer']['type'] == 'balanced_10_10_10'
        assert plan['light_target']['ppfd_min'] == 150
    
    def test_environmental_modifiers(self, rule_engine):
        """Test environmental modifier application."""
        context = {
            'species_scientific_name': 'ficus_lyrata',
            'climate_data': {
                'temp_7d_max': 35,  # Heatwave condition
                'humidity_7d_avg': 30  # Low humidity
            }
        }
        
        plan = rule_engine.apply_rules(context)
        
        # Should have heatwave adjustments
        assert plan['watering']['interval_days'] < 7  # Reduced due to heat
        assert 'heatwave_adjust_-1day' in plan['alerts']
        assert 'increase_humidity' in plan['alerts']


class TestMLAdjustmentService:
    """Test cases for MLAdjustmentService."""
    
    @pytest.fixture
    def ml_service(self):
        """Create MLAdjustmentService instance."""
        return MLAdjustmentService()
    
    def test_adjust_plan_within_bounds(self, ml_service):
        """Test ML adjustments stay within bounds."""
        base_plan = {
            'watering': {'interval_days': 7, 'amount_ml': 300},
            'fertilizer': {'interval_days': 30}
        }
        
        context = {
            'care_history': {'success_rate': 0.8},
            'environmental_stability': 0.9
        }
        
        adjusted_plan = ml_service.adjust_plan(base_plan, context)
        
        # Verify adjustments are within ±30%
        assert 5 <= adjusted_plan['watering']['interval_days'] <= 9
        assert 210 <= adjusted_plan['watering']['amount_ml'] <= 390
        assert 21 <= adjusted_plan['fertilizer']['interval_days'] <= 39


class TestRationaleBuilderService:
    """Test cases for RationaleBuilderService."""
    
    @pytest.fixture
    def rationale_service(self):
        """Create RationaleBuilderService instance."""
        return RationaleBuilderService()
    
    def test_build_comprehensive_rationale(self, rationale_service):
        """Test building comprehensive rationale."""
        context = {
            'species_scientific_name': 'ficus_lyrata',
            'avg_light_ppfd': 180,
            'temp_7d_max': 26,
            'humidity_7d_avg': 45
        }
        
        rules_applied = ['ficus_base_profile', 'normal_conditions']
        ml_adjustments = {'watering_interval': -1}
        
        rationale = rationale_service.build_rationale(context, rules_applied, ml_adjustments)
        
        assert rationale['confidence'] > 0.5
        assert 'avg_ppfd' in rationale['features']
        assert 'ficus_base_profile' in rationale['rules_fired']
        assert 'watering_interval' in rationale['ml_adjustments']
        assert len(rationale['explanation']) > 0